# condominio
Trabalho em Java para POO do 4º Período de SI Faculdade COTEMIG

Sistema para controlar pagamento das despesas de um condomínio entre os moradores
