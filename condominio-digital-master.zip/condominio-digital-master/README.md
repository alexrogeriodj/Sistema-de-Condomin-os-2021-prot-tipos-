Conta Silex
============

**Sistema para controle pessoal de contas, com cadastro de categorias, formas de pagamento e lançamentos diários.**

Sistema desenvolvido com framework silex utilizando Docttrine como fronteira de banco de dados.

O sistema no silex vai apenas dar respostas em formato JSON para qualquer interface acessar.

Controle de Acesso
==============

O sistema vai conter cadastro de usuário para pode utilizar o sistema.

O sistema vai conter authenticação através de token para acesso as informações do serviço.
