﻿using Microsoft.AspNetCore.Identity;
using System;

namespace CondominiumNetwork.DomainModel.Identity
{
    public class ApplicationUser : IdentityUser
    {
    }
}
