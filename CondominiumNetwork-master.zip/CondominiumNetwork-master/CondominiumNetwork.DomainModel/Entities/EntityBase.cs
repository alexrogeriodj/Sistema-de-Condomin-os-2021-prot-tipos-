﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CondominiumNetwork.DomainModel.Entities
{
    public abstract class EntityBase
    {
        public Guid Id { get; set; }
    }
}
