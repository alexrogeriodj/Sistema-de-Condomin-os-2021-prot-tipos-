<?php include '../partes/topo_admin.php'; ?>



                <div class="col-md-10">
                    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="jumbotron">
                                <h1>Condomínio Flamboyant</h1>
                                <p>Área restrita da Administração!</p>
                            </div>
                        </div>
                    </div>


                   

                </div>


<?php include '../partes/rodape.php'; ?>