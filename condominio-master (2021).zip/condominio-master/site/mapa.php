<?php include '../partes/topo_site.php'; ?>



                <div class="col-md-10">
                    
                    <div class="row">
                        <div class="col-md-offset-2 col-md-8 ">
                            
                            <h2> Onde estamos</h2>
                              <div class="embed-responsive embed-responsive-4by3">
                                <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d7648.507933051683!2d-47.21912264999999!3d-22.88094050000001!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c8bbe434989ffb%3A0x95e71b3f5400b434!2zMjLCsDUyJzUwLjkiUyA0N8KwMTMnMTcuNCJX!5e1!3m2!1spt-BR!2sbr!4v1441978712359" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                              </div>
                            

                        </div>
                    </div>

                </div>


<?php include '../partes/rodape.php'; ?>