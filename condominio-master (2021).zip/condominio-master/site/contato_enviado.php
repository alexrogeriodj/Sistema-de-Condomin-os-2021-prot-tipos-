<?php include '../partes/topo_site.php'; ?>



                <div class="col-md-10">
                    
                    <div class="row">
                        <div class="col-md-offset-4 col-md-4 ">
                            
                            <h2> Fale conosco</h2>
                            <p>Recebemos sua mensagem e vamos responde-la o mais rápido possível.</h5>
                            <p>Muito obrigado pela atenção</p>
                            

                        </div>
                    </div>

                </div>


<?php include '../partes/rodape.php'; ?>