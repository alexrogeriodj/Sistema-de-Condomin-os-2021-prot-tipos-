<?php include '../partes/topo_site.php'; ?>



                <div class="col-md-10">
                    
                    <div class="row">
                        <div class="col-md-offset-4 col-md-4 ">
                            
                            <h2> Confirme seus dados</h2>
                            <h3>R$ 300,00 mensais</h3>
                            
                                  <div class="form-group">
                                    <label>Nome: </label>
                                    <label>Reginaldo Marcelo dos Santos</label>
                                  </div>
                                  <div class="form-group">
                                    <label>Email: </label>
                                    <label>reginaldosantos.br@gmail.com</label>
                                  </div>
                                  <div class="form-group">
                                    <label>Senha: </label>
                                    <label>senha123</label>
                                  </div>
                                  <div class="form-group">
                                    <label>Foto</label>
                                    <img src="http://lorempixel.com/output/people-q-c-80-80-5.jpg" class="img-responsive img-thumbnail">
                                  </div>
                                  
                                  <button type="submit" class="btn btn-primary">Confirmar e fazer o pagamento</button>
                            


                        </div>
                    </div>

                </div>


<?php include '../partes/rodape.php'; ?>