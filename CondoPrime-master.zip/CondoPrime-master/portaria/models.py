# -*- encoding: utf8 -*-

from django.db import models
from condominio.models import Unidade, Espaco, Chave

# Create your models here.

