﻿angular.module('gestaoCondominioApp', ['ngRoute', 'ngResource', 'ui.bootstrap', 'ngSanitize', 'ngToast'])

