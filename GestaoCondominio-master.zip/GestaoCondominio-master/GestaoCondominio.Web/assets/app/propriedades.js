﻿angular.module('gestaoCondominioApp')
    .constant('PropriedadesConstants', {
        Endpoint: 'http://localhost:56495/'        
    });