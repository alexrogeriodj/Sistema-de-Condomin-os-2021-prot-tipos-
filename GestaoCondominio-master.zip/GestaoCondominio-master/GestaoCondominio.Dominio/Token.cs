﻿using System;

namespace GestaoCondominio.Dominio
{
    public class Token
    {
        public String sub;
        public Int32 exp;
    }
}