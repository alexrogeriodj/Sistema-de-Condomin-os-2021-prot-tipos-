package com.cotemig.exceptions;

/**
 * Created by Ian Luca on 20/11/2016.
 */
public class InvalidEmailOrPasswordException extends Exception {
}
