<div class="container">
<div class="erro">
<h1>- 404 -</h1>
<h3>PAGINA NÃO ENCONTRADA!</h3>
<div class="text-right">
<a href="<?php echo BASEURL?>" >Voltar</a>
</div>
</div>

</div>
