
<footer>			
	<p>&copy;2018 - Sistema ADMC</p>		
</footer>	
<script src="<?php echo BASEURL; ?>_support/bootstrap/js/popper.min.js"></script>
 <script src="<?php echo BASEURL; ?>_support/bootstrap/js/bootstrap.min.js"></script>
 <script defer src="<?php echo BASEURL;?>_support/fontawesome/js/fontawesome-all.js"></script>
</body>	
 
</html>