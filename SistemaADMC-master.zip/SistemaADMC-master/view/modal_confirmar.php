<div class="modal fade bd-example-modal-sm" tabindex="-1" id="confirm" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
           Deseja sair do sistema?
      </div>
      <div class="modal-footer">   
        <button type="button" data-dismiss="modal" class="btn btn-light">Não</button>
        <a href="<?php echo '?action=sair'?>" type="button" class="btn btn-danger">Sim</a>
      </div>
    </div>
  </div>
</div>