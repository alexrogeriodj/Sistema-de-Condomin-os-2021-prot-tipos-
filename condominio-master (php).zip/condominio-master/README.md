# condominio
Sistema de gestão do condomínio Porto Seguro II.


Modulos do sistema:

1. Chamado;

2. Circular;

3. Contato;

4. Enquete;

5. Funcionario;

6. Melhoria;

7. Morador;

8. Prestador de serviços;

9. Salão de festas.



Linguagem de desenvolvimento: PHP.

Adianti Framework
